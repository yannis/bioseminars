module SeleniumOnRails # :nodoc
end

require 'selenium_on_rails/selenese'
require 'selenium_on_rails/test_builder'
require 'selenium_on_rails/rselenese'
require 'selenium_on_rails/suite_renderer'
require 'selenium_on_rails/paths'
require 'selenium_on_rails/fixture_loader'
require 'selenium_on_rails/partials_support'
require 'selenium_on_rails/renderer'
