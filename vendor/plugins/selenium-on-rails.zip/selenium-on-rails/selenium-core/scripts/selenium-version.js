Selenium.version = "1.0-beta-2";
Selenium.revision = "2330";

window.top.document.title += " v" + Selenium.version + " [" + Selenium.revision + "]";

