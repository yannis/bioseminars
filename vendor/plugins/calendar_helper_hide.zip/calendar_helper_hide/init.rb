ActionView::Base.send :include, CalendarHelper
