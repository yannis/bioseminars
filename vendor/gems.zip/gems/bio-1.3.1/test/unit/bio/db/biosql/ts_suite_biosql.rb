# To change this template, choose Tools | Templates
# and open the template in the editor.
$:.unshift File.dirname(__FILE__)

require 'test/unit' 

# Add your testcases here
require 'tc_biosql'
